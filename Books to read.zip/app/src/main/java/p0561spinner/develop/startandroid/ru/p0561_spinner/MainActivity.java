package p0561spinner.develop.startandroid.ru.p0561_spinner;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;


public class MainActivity extends Activity {

    String[] data = {"Fantasy", "Historical", "Science", "Detective", "Romance"};

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        final TextView myText1View = (TextView) findViewById(R.id.myText1);
        final TextView myText2View = (TextView) findViewById(R.id.myText2);
        final TextView myText3View = (TextView) findViewById(R.id.myText3);
        final LinearLayout layout = (LinearLayout)findViewById(R.id.layout);
        final ImageButton imgBut = (ImageButton) findViewById(R.id.imageButton);
        final ImageButton imgBut2 = (ImageButton) findViewById(R.id.imageButton2);
        final ImageButton imgBut3 = (ImageButton) findViewById(R.id.imageButton3);
        final Button button1 = (Button) findViewById(R.id.button3);
        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.bookfb2.ru/"));
                startActivity(browserIntent);
            }
        });



        imgBut.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent browserIntent1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://vk.com/r2d2c2"));
                startActivity(browserIntent1);
            }
        });

        imgBut2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent browserIntent2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://plus.google.com/114539537752930989999"));
                startActivity(browserIntent2);
            }
        });

        imgBut3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent browserIntent3 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/father1frost"));
                startActivity(browserIntent3);
            }
        });

        ImageButton send;
        send = (ImageButton) findViewById(R.id.emailsendbutton);
        send.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);

                EditText address, subject, emailtext;
                address = (EditText) findViewById(R.id.emailaddress);
                subject = (EditText) findViewById(R.id.emailsubject);
                emailtext = (EditText) findViewById(R.id.emailtext);

                emailIntent.setType("plain/text");
                // mail adressed to
                emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,
                        new String[]{address.getText().toString()});
                // Subject
                emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
                        subject.getText().toString());
                // email text
                emailIntent.putExtra(android.content.Intent.EXTRA_TEXT,
                        emailtext.getText().toString());
                emailIntent.setType("plain/text");
                startActivity(Intent.createChooser(emailIntent,
                        "Отправка письма..."));
            }
        });

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, data);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setAdapter(adapter);
        spinner.setSelection(0);

        button1.setBackgroundColor(Color.DKGRAY);

        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                ((TextView) parent.getChildAt(0)).setTextSize(24);
                switch (position) {
                    case 0:
                        myText1View.setText("1.The Lord of the Rings by Tolkien");
                        myText2View.setText("2.A Song of Ice and Fire by Martin");
                        myText3View.setText("3.Harry Potter by J. Roaling");
                        break;
                    case 1:
                        myText1View.setText("1.John Adams by David McCullough ");
                        myText2View.setText("2.Team of Rivals: The Political Genius of Abraham Lincoln by Doris Kearns Goodwin ");
                        myText3View.setText("3.The Rise and Fall of the Third Reich: A History of Nazi Germany by William L. Shirer ");
                        break;
                    case 2:
                        myText1View.setText("1.On the Move by Oliver Sacks");
                        myText2View.setText("2.The Invention of Nature by Alexandr von Humboldt");
                        myText3View.setText("3.Dark Matter and the Dinosaurs by Lisa Randall" );
                        break;
                    case 3:
                        myText1View.setText("1.Stranger on a Train by Patricia Highsmith");
                        myText2View.setText("2.The Complete Sherlock Holmes by Arthur Conan Doyle");
                        myText3View.setText("3.The Madman of Bergerac Georges Simenon");
                        break;
                    case 4:
                        myText1View.setText("1.Outlander by Diana Gabaldon");
                        myText2View.setText("2.The Bride by Julie Garwood");
                        myText3View.setText("3.Knight in Shining Armor by Jude Devereaux" );
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
    }
}
